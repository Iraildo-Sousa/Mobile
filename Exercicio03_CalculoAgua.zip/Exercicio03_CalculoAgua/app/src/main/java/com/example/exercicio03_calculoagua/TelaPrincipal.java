package com.example.exercicio03_calculoagua;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;

public class TelaPrincipal extends AppCompatActivity {


    EditText caixaNome, caixaIdade, caixaPeso, CaixaTemperatura;
    Button botaoAgua;

    MultiAutoCompleteTextView caixaResultado;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_principal);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        caixaIdade = findViewById(R.id.caixaIdade);
        caixaNome = findViewById(R.id.caixaNome);
        caixaPeso = findViewById(R.id.caixaPeso);
        CaixaTemperatura = findViewById(R.id.caixaTemperatura);
        botaoAgua = findViewById(R.id.botaoAgua);
        caixaResultado = findViewById(R.id.caixaResultado);

        DecimalFormat formatarDecimal = new DecimalFormat("###,#0.0");

        botaoAgua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {





                if (Double.parseDouble(CaixaTemperatura.getText().toString()) <= 32) {

                    double receber = calculo32();

                   caixaResultado.setText("\nOlá " + caixaNome.getText() + "\nVocê tem " + caixaIdade.getText() + " anos" +
                            "\nSeu peso é " + caixaPeso.getText() + "\n E com a temperatura " + CaixaTemperatura.getText() + "\nVocê precisa tomar "
                            + formatarDecimal.format(receber) + " litros de água.");
                    
                }

                else if (Double.parseDouble(CaixaTemperatura.getText().toString()) > 32 && Double.parseDouble(CaixaTemperatura.getText().toString()) <= 37) {

                    double receber = calculo32_37();

                    caixaResultado.setText("\nOlá " + caixaNome.getText() + "\nVocê tem " + caixaIdade.getText() + " anos" +
                            "\nSeu peso é " + caixaPeso.getText() + "\n E com a temperatura " + CaixaTemperatura.getText() + "\nVocê precisa tomar "
                            + formatarDecimal.format(receber) + " litros de água.");


                }

                else if (Double.parseDouble(CaixaTemperatura.getText().toString()) > 32 && Double.parseDouble(CaixaTemperatura.getText().toString()) > 37) {

                    calculo37();

                    double receber = calculo37();

                    caixaResultado.setText("\nOlá " + caixaNome.getText() + "\nVocê tem " + caixaIdade.getText() + " anos" +
                            "\nSeu peso é " + caixaPeso.getText() + "\n E com a temperatura " + CaixaTemperatura.getText() + "\nVocê precisa tomar "
                            + formatarDecimal.format(receber) + " litros de água.");


                }

            }
        });

    }

    public double calculo32() {

        double multiplicacao = (Double.parseDouble(caixaPeso.getText().toString()) * 35)/1000;

        return multiplicacao;
    }

    public double calculo32_37() {

        double multiplicacao = (Double.parseDouble(caixaPeso.getText().toString()) * (35+10))/1000;

        return multiplicacao;
    }

    public double calculo37() {

        double multiplicacao = (Double.parseDouble(caixaPeso.getText().toString()) * (35+30))/1000;

        return multiplicacao;
    }

}