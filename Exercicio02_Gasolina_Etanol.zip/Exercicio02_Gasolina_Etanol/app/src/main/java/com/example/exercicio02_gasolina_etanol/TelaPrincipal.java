package com.example.exercicio02_gasolina_etanol;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class TelaPrincipal extends AppCompatActivity {

    EditText caixaEtanol, caixaGasolina;
    Button botaoCalculo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tela_principal);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        caixaEtanol = findViewById(R.id.caixaEtanol);
        caixaGasolina = findViewById(R.id.caixaGasolina);
        botaoCalculo = findViewById(R.id.botaoCalculo);

        // etanol / gasolina se maior que 0,7 abasteça com gasolina ou se menor ou igual à 0.7 abasteça com etanol
        //Toast.makeText(getApplication(), , Toast.LENGTH_SHORT).show();
        // 6.57 gasolina e 4.59 etanol


botaoCalculo.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        double etanol = Double.parseDouble(caixaEtanol.getText().toString());
        double gasolina = Double.parseDouble(caixaGasolina.getText().toString());

        double calculo = etanol / gasolina;

        if (calculo <= 0.7) {

            Toast.makeText(getApplication(), "Abasteça com etanol", Toast.LENGTH_SHORT).show();
            
        }

        else {

            Toast.makeText(getApplication(), "Abasteça com gasolina", Toast.LENGTH_SHORT).show();

        }

    }
});


    }
}