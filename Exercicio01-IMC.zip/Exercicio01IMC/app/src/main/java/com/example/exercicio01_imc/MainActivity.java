package com.example.exercicio01_imc;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    MultiAutoCompleteTextView textoResultado;

    Button botaoCalcular;

    EditText caixaPeso, caixaAltura, caixaNome, caixaIdade;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });

        botaoCalcular = findViewById(R.id.botaoCalcular);
        caixaAltura = findViewById(R.id.caixaAltura);
        caixaPeso = findViewById(R.id.caixaPeso);
        textoResultado = findViewById(R.id.textoResultado);
        caixaNome = findViewById(R.id.caixaNome);
        caixaIdade = findViewById(R.id.caixaIdade);

        botaoCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                double peso = Double.parseDouble(caixaPeso.getText().toString());
                double altura = Double.parseDouble(caixaAltura.getText().toString());
                double calculoIMC = peso / (altura * altura);

                textoResultado.setText(String.valueOf(calculoIMC));

                if (calculoIMC < 18.5 && calculoIMC > 0) {

                    textoResultado.setText("Seu nome é: " + caixaNome.getText() + "\nIdade: " + caixaIdade.getText() + "\nVocê está abaixo do peso = " + String.valueOf(calculoIMC));


                } // Fim do if

                else if (calculoIMC <= 24.9 && calculoIMC >= 18.5) {

                    textoResultado.setText("Seu nome é: " + caixaNome.getText() + "\nIdade: " + caixaIdade.getText() + "\nVocê está com peso normal" +
                            " = " + String.valueOf(calculoIMC));


                } // fim do if else

                else if (calculoIMC < 30 && calculoIMC >= 25) {

                    textoResultado.setText("Seu nome é: " + caixaNome.getText() + "\nIdade: " + caixaIdade.getText() + "\nVocê está com sobrepeso" +
                            " = " + String.valueOf(calculoIMC));

                } // fim do if else


                else if (calculoIMC < 35 && calculoIMC >= 30) {

                    textoResultado.setText("Seu nome é: " + caixaNome.getText() + "\nIdade: " + caixaIdade.getText() + "\nObesidade grau 1" +
                            " = " + String.valueOf(calculoIMC));

                } // fim do if else


                else if (calculoIMC < 40 && calculoIMC >= 35) {

                    textoResultado.setText("Seu nome é: " + caixaNome.getText() + "\nIdade: " + caixaIdade.getText() + "\nObesidade grau 2" +
                            " = " + String.valueOf(calculoIMC));

                } // fim do if else */

                else if (calculoIMC < 50 && calculoIMC >= 40) {

                    textoResultado.setText("Seu nome é: " + caixaNome.getText() + "\nIdade: " + caixaIdade.getText() + "\nObesidade grau 3" +
                            " = " + String.valueOf(calculoIMC));

                } // fim do if else

                else if (calculoIMC < 60 && calculoIMC >= 50) {

                    textoResultado.setText("Seu nome é: " + caixaNome.getText() + "\nIdade: " + caixaIdade.getText() + "\nObesidade grau 4" +
                            " = " + String.valueOf(calculoIMC));

                } // fim do if else

                else if (calculoIMC >= 60) {

                    textoResultado.setText("Seu nome é: " + caixaNome.getText() + "\nIdade: " + caixaIdade.getText() + "\nObesidade grau 5" +
                            " = " + String.valueOf(calculoIMC));

                } // fim do if else

            }

        });



    }
}